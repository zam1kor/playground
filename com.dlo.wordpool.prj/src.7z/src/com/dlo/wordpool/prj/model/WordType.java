package com.dlo.wordpool.prj.model;

public enum WordType {

	GOOD,BAD
}
