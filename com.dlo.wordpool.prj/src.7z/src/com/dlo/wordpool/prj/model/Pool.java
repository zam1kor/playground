package com.dlo.wordpool.prj.model;

import java.util.Collection;
import java.util.Map;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class Pool {

	private int id;

	private String name;

	private Table<Integer, String, Word> wordsMap;

	private PoolManager manager;


	protected Pool( int id, String name, PoolManager manager){
		this.id=id;
		this.name=name;
		this.manager=manager;
		wordsMap=HashBasedTable.create() ;
	}


	public int getId() {
		return id;
	}


	public String getName() {
		return name;
	}

	public Collection< Word> getAllWords() {
		return wordsMap.values();
	}


	public PoolManager getPoolManager() {
		return manager;
	}


	/*
	 * This method should ensure that duplicate words are not stored.
	 * Note: This method is case sensitive
	 */
	public Word addWord(Integer ID, String text){


		if(wordsMap.contains(ID, text)){
			return wordsMap.get(ID, text);
		}

		Word word = new Word(ID,text,this);


		wordsMap.put(ID, text, word);

		return word;


	}

	protected Word addWord(Word word){


		if(wordsMap.contains(word.getID(), word.getText())==false){

			wordsMap.put(word.getID(), word.getText(), word);
		}

		return word;

	}


	public Word getWord(Integer ID){

		Map<String, Word> row1 = wordsMap.row(ID);

		if(row1 != null){

			return row1.values().size()>0?row1.values().toArray(new Word[6])[0]:null;
		}

		return null;
	}

	public Word getWord(String  text){

		Map<Integer, Word> column = wordsMap.column(text);

		if(column != null){

			return column.values().size()>0?column.values().toArray(new Word[6])[0]:null;
		}

		return null;
	}


	public boolean isWordIDExists( Integer id){

		return wordsMap.containsRow(id);
	}

	public boolean isWordExists(String text){
		return wordsMap.containsColumn(text);
	}

	@Override
	public String toString() {
		return "Pool [id=" + id + ", name=" + name + ", wordsMap=" + wordsMap
				+ ", manager=" + manager + "]";
	}

}
