package com.dlo.wordpool.prj.test;

import java.util.Collection;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dlo.wordpool.prj.model.Pool;
import com.dlo.wordpool.prj.model.PoolManager;

public class Test {

	public static void main(String[] args) {
		
		System.setProperty("log4j.configurationFile", ".\\log4j2-test.xml");
		
		Logger logger = LogManager.getLogger(Test.class.getName());
		
		PoolManager poolManager=PoolManager.getInstance();
		
		
		for(int i=0;i<100;i++){
			Pool pool = poolManager.createPool(i, "Test"+i);

			pool.addWord(1, "Hello");
			
		}
		
		
		System.out.println(poolManager.getPoolNames());
		
		
	
		Collection<Pool> allPoolsUsingWord = poolManager.getAllPoolsUsingWord(1);
		
		System.out.println(allPoolsUsingWord);

		
		Collection<Pool> allPoolsUsingWord2 = poolManager.getAllPoolsUsingWord("Hello");
		
		System.out.println(allPoolsUsingWord2);
		
		logger.log(Level.ERROR, "hello");
	}
}
